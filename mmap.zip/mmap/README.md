##Assignment 2
##Owen Martin

1. I thought that I implemented everything correctly, but the map doesn't load
on any of my browsers. Everything else in my code is correct (the post to 
the secret box, receiving the other data, etc) but for some reason the map API
doesn't load despite my code telling it to :/

2. I collaborated briefly with Matt P. and Justin S. on this assignment, as 
well as using some of Ming's code

3. I spent about 15 hours on this assignment
 